<style type="text/css">
.wp-admin select{ width:25em;}
.error {color: #FF0000;}
</style>
<?php
global $wpdb;

function serialkeygenerator()
{
$chars = array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
$serial = '';
$max = count($chars)-1;
for($i=0;$i<15;$i++)
{
    $serial .= (!($i % 5) && $i ? '-' : '').$chars[rand(0, $max)];
	//$serial .= $chars[rand(0, $max)];
}
   return $serial;
}

if(isset($_POST['createserial'])){
   $err = '';
$now = current_time('mysql', false);

if(empty($_POST['pro_name'])){
$errpro = 'Please Select Product ';
}
if(empty($_POST['grop_name'])){
$errgro = 'Please Select Group ';
}
if($_POST['serialnmber'] <= 0){
$errnmbr = "Please Enter Serail number Greater than zero"; 
}

if(empty($_POST['serail_name'])){
    $gropname  			= "Select * from wp_productgroup where id = '".$_POST['grop_name']."'";
	$gropreslt 			= $wpdb->get_row($gropname);  
	$serialcreatroname  = $gropreslt->name; 
}
else{
   $serialcreatroname  = $_POST['serail_name'];
}

if(empty($errpro) && empty($errgro) && empty($errnmbr))
{
   $product_id	   = 	$_POST['pro_name'];
   $prquery        =	"select * from wp_products where id = ".$product_id."";   
   $result 		   = 	$wpdb->get_row($prquery);
   $prefix 		   = 	$result->serial_prefix;
   //$serailkey   =   $prefix."-".serialkeygenerator();   
   
   $counter = $_POST['serialnmber']; 
   $wpdb->insert('wp_serialskeycreator', array(
    'create_date'          	=> $now,
    'name' 					=> $serialcreatroname,
    'notes'  				=> $_POST['serail_notes'],
	'number_of_serials' 	=> $_POST['serialnmber'],
	'product_id' 			=> $_POST['pro_name'],
	'group_id'  			=> $_POST['grop_name'],
));
  $serialsid = $wpdb->insert_id;
 if($serialsid){
 for($i=1; $i<=$counter;$i++){
   $serailnumber   =   serialkeygenerator();
   $prefix    	   =   $prefix;
   $prefixlength   =   strlen($prefix);  
   $serailkey 	   =   substr_replace($serailnumber, $prefix, 0 , $prefixlength);
   
	$wpdb->insert('wp_serials', array(
    'serial_code' 			=> $serailkey,
    'product_id'  			=> $product_id,
	'registered_to_user' 	=> 0,
	'created_by' 			=> $serialsid,
	'num_activations'  		=> 0,
	'register_date'         => '0000-00-00 00:00:00',
));
}
  echo "<strong>Serials added successfully</strong>"; 
  echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=serials-management'</script>");
  exit();
}
}
}
?>
<script src="//code.jquery.com/jquery-1.9.1.js"></script>
  <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
  
  <!-- jQuery Form Validation code -->
  <script>
  // When the browser is ready...
  $(function() {
  
    // Setup form validation on the #register-form element
    $("#createuser").validate({
    
        // Specify the validation rules
        rules: {
            pro_name: "required",
			grop_name: "required",
            pro_id: "required",
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 5
            },
            testfield: "required"
        },
        
        // Specify the validation error messages
        messages: {
            pro_name: "Please Select Product",
            grop_name: "Please Select Group",
            pro_id: "Please enter your Product id"
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

  });
  </script>

<h2>Enter Serials Details</h2>
<form action="" method="post" name="createuser" id="createuser" novalidate="novalidate">
<table class="form-table">
	<tbody>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Product <span class="description">(required)</span></label></th>
		<td>
		<select name="pro_name" id="pro_name">
  		<option value="">Select Product</option>
		<?php
		$querydata  = "select * from wp_products";
		$resultspro = $wpdb->get_results($querydata);
		foreach ($resultspro as $datapro) 
		{
		?>
		<?php 
		if($_POST['pro_name'] == $datapro->id)
		{
		?>
		<option selected="selected" value="<?php echo $datapro->id; ?>"><?php echo $datapro->name; ?></option>
		<?php }
		else
		{
		?>
		<option value="<?php echo $datapro->id; ?>"><?php echo $datapro->name; ?></option>
		<?php
		}
		 ?>
		<?php
		 } ?>
		</select>
		<span class="error"><?php echo $errpro;?></span>
		</td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Group</label></th>
		<td>
		<select name="grop_name" id="grop_name">
  		<option value="">Select Group</option>
		<?php
		$querydata = "select * from wp_productgroup";
		$results = $wpdb->get_results($querydata);
		foreach ($results as $data) {
		?>
		<?php 
		if($_POST['grop_name'] == $data->id){
		?>
		  <option selected="selected" value="<?php echo $data->id; ?>"><?php echo $data->name ?></option>
		<?php }
		else
		{
		?>
		<option value="<?php echo $data->id; ?>"><?php echo $data->name ?></option>
		<?php
		}
		 ?>
		<?php
		 }
		 ?>
		</select>
		<span class="error"><?php echo $errgro; ?></span>
		</td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Serial Name</label></th>
		<td><input name="serail_name" type="text" value="<?php echo $_POST['serail_name'] ?>" id="serail_name">	
		 </td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="email">Number of Serials </span></label></th>
		<td><input name="serialnmber" type="number"  id="serialnmber" value="<?php echo $_POST['serialnmber'] ?>">
		<span class="error"><?php echo $errnmbr; ?></span>
		</td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="first_name">Notes </label></th>
		<td><input name="serail_notes" type="text" id="serail_notes" value="<?php echo $_POST['serail_notes'] ?>"></td>
	</tr>
	</tbody></table>

<p class="submit"><input type="submit" name="createserial" id="createserial" class="button button-primary" value="Add New Serial"></p>
</form>
