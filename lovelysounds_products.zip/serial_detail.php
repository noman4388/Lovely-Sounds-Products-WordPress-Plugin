<?php
global $wpdb;

$querydata = "select * from wp_serials where created_by = ".$_GET['proid']." AND registered_to_user != 0 ORDER BY register_date DESC";
$results = $wpdb->get_results($querydata);

$querycreator 	= 	"select * from wp_serialskeycreator where id = ".$_GET['proid']."";
$queryreslt   	= 	$wpdb->get_row($querycreator);
$creatorname  	= 	$queryreslt->name;
$creatornotes  	= 	$queryreslt->notes;	
$createdata		=   $queryreslt->create_date;

	      $prquery          	=	"select * from wp_products where id = ".$queryreslt->product_id."";   
		  $resultpro 			= 	$wpdb->get_row($prquery);
		  $productname			=   $resultpro->name;
		  
		  $grquery          	=	"select * from wp_productgroup where id = ".$queryreslt->group_id."";   
		  $resultgro 			= 	$wpdb->get_row($grquery);
		  $reseller				=   $resultgro->name;

?>
<div class="wrap">
 <h2> Serial Creator </h2>
  <form action="" method="get">
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
          <th scope="col" id="username" class="manage-column column-username sortable desc">
		<span>Create Date</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">
		  <span>Group/Reseller</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">
		  <span>Product</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">Creator Name</th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">Notes</th>
      </thead>
	  <tr id="user-4" class="alternate">
      <td class="name column-name">
	   <strong><?php echo date('Y-m-d', strtotime($createdata)); ?></strong><br>
	  </td>
	  <td class="name column-name"><?php echo $reseller; ?></td>
	  <td class="name column-name"><?php echo $productname; ?></td>
	  <td class="name column-name"><?php echo $creatorname; ?></td>
	  <td class="name column-name"><?php echo $creatornotes; ?></td>
	</tr>
    </table>
  </form>
  <br class="clear">
</div>

<div class="wrap">
  <h2> Registered Serials <a href="<?php echo site_url(); ?>/wp-admin/admin.php?page=serials-management&action=export-register&proid=<?php echo $_GET['proid']; ?>" class="add-new-h2">Export</a> </h2>
  <form action="" method="get">
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
		<th scope="col" id="cb" class="manage-column column-cb" style="">
		<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
            <input id="cb-select-all-1" type="checkbox">
			</th>
          <th scope="col" id="username" class="manage-column column-username sortable desc">
		<span>Serial Code</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">
		  <span>User Name</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">
		  <span>Number of Activation</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">Date</th>
      </thead>
	  <?php foreach ($results as $data) { 
	    $user_info = get_userdata($data->registered_to_user);
        $userlogin	=	$user_info->user_login;			 
	  ?>
	  <tr id="user-4" class="alternate">
      <th scope="row"><label class="screen-reader-text" for="cb-select-4">Select abbr1</label>
        <input type="checkbox" name="users[]" id="user_<?php echo $data->id; ?>" class="group_leader" value="<?php echo $data->id; ?>"></th>
      <td class="name column-name">
	   <strong><?php echo $data->serial_code; ?></strong><br>
	  </td>
	  <td class="name column-name"><?php echo $userlogin; ?></td>
	  <td class="name column-name"><?php echo $data->num_activations; ?></td>
	  <td class="name column-name"><?php echo date('Y-m-d', strtotime($data->register_date)); ?></td>
	</tr><?php 
	} ?>
    </table>
  </form>
  <br class="clear">
</div>
<?php

$querydata = "select * from wp_serials where created_by = ".$_GET['proid']." AND registered_to_user = 0";
$results = $wpdb->get_results($querydata);

$querycreator = 	"select * from wp_serialskeycreator where id = ".$_GET['proid']."";
$queryreslt   	= 	$wpdb->get_row($querycreator);
$creatorname  	= 	$queryreslt->name;
$creatornotes  	= 	$queryreslt->notes;	
?>
<div class="wrap">
  <h2> Un-Registered Serials <a href="<?php echo site_url(); ?>/wp-admin/admin.php?page=serials-management&action=export-unregister&proid=<?php echo $_GET['proid']; ?>" class="add-new-h2">Export</a> </h2>
  <form action="" method="get">
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
		<th scope="col" id="cb" class="manage-column column-cb" style="">
		<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
            <input id="cb-select-all-1" type="checkbox">
			</th>
          <th scope="col" id="username" class="manage-column column-username sortable desc">
		<span>Serial Code</span>
		  </th>
      </thead>
	  <?php foreach ($results as $data) { 			 
	  ?>
	  <tr id="user-4" class="alternate">
      <th scope="row"><label class="screen-reader-text" for="cb-select-4">Select abbr1</label>
        <input type="checkbox" name="users[]" id="user_<?php echo $data->id; ?>" class="group_leader" value="<?php echo $data->id; ?>"></th>
      <td class="name column-name">
	   <strong><?php echo $data->serial_code; ?></strong><br>
	  </td>
	</tr><?php 
	} ?>
    </table>
  </form>
  <br class="clear">
</div>