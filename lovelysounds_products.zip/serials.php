<?php
global $wpdb;

$querydata = "select * from wp_serialskeycreator ORDER BY create_date DESC";

/*$querydata = "SELECT * FROM
(
    SELECT * FROM wp_serialskeycreator
    ORDER BY create_date DESC
    LIMIT 100
) T1
ORDER BY RAND()";
*/
$results = $wpdb->get_results($querydata);
 ?>
<div class="wrap">
  <h2> Serials <a href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=add-newserials" class="add-new-h2">Add New Serials</a> </h2>
  <form action="" method="get">
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
		<th scope="col" id="cb" class="manage-column column-cb" style="">
		<label class="screen-reader-text" for="cb-select-all-1">Select All</label>
            <input id="cb-select-all-1" type="checkbox">
			</th>
          <th scope="col" id="username" class="manage-column column-username sortable desc">
		<span>Product Name</span>
		  </th>
          <th scope="col" id="email" class="manage-column column-email sortable desc">
		  <span>Group Name</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">
		  <span>Serial Creator Name</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">
		  <span>Notes</span>
		  </th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">Numbers of Serials</th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">Registered Serials</th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">Avail Serials</th>
		  <th scope="col" id="email" class="manage-column column-email sortable desc">Creation Date</th>
      </thead>
	  <?php foreach ($results as $data) { 			 
			 
	      $prquery          	=	"select * from wp_products where id = ".$data->product_id."";   
		  $resultpro 			= 	$wpdb->get_row($prquery);
		  
		  $grquery          	=	"select * from wp_productgroup where id = ".$data->group_id."";   
		  $resultgro 			= 	$wpdb->get_row($grquery);
	  
	     //// ****  serials code ****///
		 $creatorid = $data->id;
		 $serailquery          	=	"select * from wp_serials where created_by = ".$creatorid."";   
		 $serailresult         	=    $wpdb->get_results($serailquery); 
		 $numberserail		   	=    count($serailresult);
		 
		 $registerserail       	=	"select * from wp_serials where created_by = ".$creatorid." and registered_to_user != 0";  
	     $registerreslut	   	=    $wpdb->get_results($registerserail);  
		 $registerserial	   	=    count($registerreslut); 
	  
	     $availserial			=    $numberserail - $registerserial;
	      
	     //foreach($serailresult as $serail)
		 {
	  ?>
	 
	  <tr id="user-4" class="alternate">
      <th scope="row"><label class="screen-reader-text" for="cb-select-4">Select abbr1</label>
        <input type="checkbox" name="users[]" id="user_<?php echo $data->id; ?>" class="group_leader" value="<?php echo $data->id; ?>"></th>
      <td class="name column-name">
	   <strong><?php echo $resultpro->name ?></strong><br>
        <!--<div class="row-actions">
		<span class="edit"><a href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=edit-newgroup&group_id=<?php echo $data->id; ?>">Edit</a> | </span>
		<span class="delete">
		<a onclick="return confirm('Are you sure you want to delete this product?');" class="submitdelete" href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=delete-newgroup&group_id=<?php echo $data->id; ?>">Delete</a>
		</span></div> -->
		</td>
      <td class="name column-name"><?php echo $resultgro->name; ?></td>
	  <td class="name column-name"><?php echo $data->name; ?></td>
	  <td class="name column-name"><?php echo $data->notes; ?></td>
	  <td class="name column-name"><?php echo $numberserail; ?></td>
	  <td class="name column-name"><?php echo $registerserial; ?></td>
	  <td class="name column-name"><?php echo $availserial; ?></td>
	  <td class="name column-name"><?php echo date('Y-m-d',strtotime($data->create_date)); ?></td>
	  <td class="name column-name"><a href="<?php echo site_url(); ?>/wp-admin/admin.php?page=serials-management&action=details&proid=<?php echo $data->id; ?>">View Detail</a></td>
	</tr><?php }
	} ?>
    </table>
  </form>
  <br class="clear">
</div>
