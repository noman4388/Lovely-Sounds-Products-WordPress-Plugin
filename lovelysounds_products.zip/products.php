<?php

global $wpdb;

$querydata = "select * from wp_products";

$results = $wpdb->get_results($querydata);
 ?>
 
<div class="wrap">
  <h2> Products <a href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=add-newproduct" class="add-new-h2">Add New Product</a> </h2>
  <form action="" method="get">
    <div class="tablenav top">
      <div class="tablenav-pages one-page"><span class="displaying-num">4 items</span> <span class="pagination-links"><a class="first-page disabled" title="Go to the first page" href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php">«</a> <a class="prev-page disabled" title="Go to the previous page" href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?paged=1">‹</a> <span class="paging-input">
        <label for="current-page-selector" class="screen-reader-text">Select Page</label>
        <input class="current-page" id="current-page-selector" title="Current page" type="text" name="paged" value="1" size="1">
        of <span class="total-pages">1</span></span> <a class="next-page disabled" title="Go to the next page" href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?paged=1">›</a> <a class="last-page disabled" title="Go to the last page" href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?paged=1">»</a></span></div>
      <br class="clear">
    </div>
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
          <th scope="col" id="cb" class="manage-column column-cb check-column" style=""><label class="screen-reader-text" for="cb-select-all-1">Select All</label>
            <input id="cb-select-all-1" type="checkbox"></th>
          <th scope="col" id="username" class="manage-column column-username sortable desc" style="">
		  <a href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?orderby=login&amp;order=asc"><span>Product Name</span><span class="sorting-indicator"></span></a>
		  </th>
          <th scope="col" id="name" class="manage-column column-name sortable desc" style="">
		  <a href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?orderby=name&amp;order=asc"><span>Product Id</span><span class="sorting-indicator"></span></a>
		  </th>
		  <th scope="col" id="name" class="manage-column column-name sortable desc" style="">
		  <a href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?orderby=name&amp;order=asc"><span>Product Guid</span><span class="sorting-indicator"></span></a>
		  </th>
          <th scope="col" id="email" class="manage-column column-email sortable desc" style=""><a href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?orderby=email&amp;order=asc"><span>Vendor</span><span class="sorting-indicator"></span></a></th>
          <th scope="col" id="roles" class="manage-column column-roles" style="">Download Link</th>
          <th scope="col" id="posts" class="manage-column column-posts num" style="">Serial Prefix</th>
      </thead>
	  <?php
	  foreach($results as $record){
	   ?>
	  <tr id="user-4" class="alternate">
      <th scope="row" class="check-column"><label class="screen-reader-text" for="cb-select-4">Select abbr1</label>
        <input type="checkbox" name="users[]" id="user_<?php echo $record->id; ?>" class="group_leader" value="<?php echo $record->id; ?>"></th>
      <td class="username column-username">
	   <strong>
	   <a href="http://58.65.172.229:808/lovelysounds/wp-admin/user-edit.php?user_id=4&amp;wp_http_referer=%2Fevs%2Fnoman%2Fwordpressnewsite%2Fwp-admin%2Fusers.php"><?php echo $record->name ?></a></strong><br>
        <div class="row-actions">
		<span class="edit"><a href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=edit-product&product_id=<?php echo $record->id; ?>">Edit</a> | </span>
		<?php
		$queryprocheck = "select * from wp_serialskeycreator where product_id = '".$record->id."'";
		$resultcheck = count($wpdb->get_results($queryprocheck));
		if($resultcheck == 0)
		{
		 ?>
		<span class="delete">
		<a onclick="return confirm('Are you sure you want to delete this product?');" class="submitdelete" href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=delete-product&product_id=<?php echo $record->id; ?>">Delete</a>
		</span>
		<?php
		 } 
		 ?>
		</div></td>
      <td class="name column-name"><?php echo $record->product_id; ?></td>
      <td class="email column-email"><?php echo $record->product_guid; ?></td>
      <td class="roles column-roles"><?php echo $record->vendor; ?></td>
      <td class="posts column-posts num"><?php echo $record->downloadlink; ?></td>
	  <td class="posts column-posts num"><?php echo $record->serial_prefix ?></td>
    </tr>
	<?php } ?> 
    </table>
	
  </form>
  <br class="clear">
</div>
