<?php
/**
 * Template Name: My Account
*/
get_header(); ?>
<style>
table, th, td{ border:0px;}
.error {color: #FF0000;}
</style>
<script type="text/javascript">
function returnurl(){
	location.href='http://58.65.172.229:808/lovelysounds/my-account-testing/';
}
</script>

<div id="main-content" class="main-content">

	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
<?php
if($_GET['action'] == 'newpro'){
	global $wpdb;  
$now = current_time('mysql', false);
$user_id = get_current_user_id();
	if(isset($_POST['registerproduct'])){
		
	
	$serailnmber 	 =	 $_POST['serail_number'];
   	$querypro  		 = 	 "select * from wp_serials where serial_code = '".$serailnmber."' ";
   	$getresult 		 = 	 $wpdb->get_row($querypro); 

	$queryserial  	 = 	 "select * from wp_productactivations where serial_id = '".$serailnmber."' ";
   	$serailresult 	 = 	 $wpdb->get_row($queryserial); 
	
	
	
	
	if(!empty($getresult) && empty($serailresult) && !empty($serailnmber))
	{
		
	$wpdb->insert('wp_productactivations', array(
    'activation_date'          =>  $now,
    'user_id' 				   =>  $user_id,
    'serial_id' 			   =>  $getresult->serial_code,
    'product_id'  			   =>  $getresult->product_id,
));

if($wpdb->insert_id){
   $updatequery =  "UPDATE wp_serials SET  register_date = '".$now."', registered_to_user = '".$user_id."' WHERE serial_code = '".$_POST['serail_number']."'";
   $updateqry = $wpdb->query($updatequery);
  echo "<strong>Product Registered successfully</strong><br>"; 
  echo "<input type='button' name='data' value='Ok' onclick='returnurl();' >";
  //echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=my-products</script);
  exit();
}
	}
	if(empty($serailnmber)){
		$error = 'Please Enter Serial Key';
	}
	
	elseif(!empty($serailresult)){
        $error = 'Serial Key is Already Registered';
 }	
 else{
        $error = "Invalid Serial Key";
 }
		
	}
	
	?>
	<div style="margin-left:2%;">
	<h2>Please Enter your Serial Number to Register New Product</h2>
   <span class="error"><strong><?php echo $error; ?></strong></span>
<form action="" method="post" name="createuser" id="createuser" class="validate">
<table class="form-table">
	<tbody>
	<tr class="form-field">
		<th scope="row"><label for="first_name">Serial: </label></th>
		<td><input name="serail_number" type="text" id="serail_number" value="<?php echo $_POST['serail_number'] ?>" required></td>
	</tr>
	</tbody></table>

<p class="submit"><input type="submit" name="registerproduct" id="registerproduct" class="button button-primary" value="Send"></p>
</form>
</div>
	
	<?php
}
else{
 ?>
				<header class="entry-header"><h1 class="entry-title">my products</h1></header>
				<?php
global $wpdb;
$user_id = get_current_user_id();
$querydata = "select * from wp_serials where registered_to_user = '".$user_id ."' order by `register_date` desc";
$results = $wpdb->get_results($querydata);
 ?>
<div class="wrap" style="margin-left:1%;">
 <a href="<?php echo home_url() ?>/my-account/?action=newpro" class="add-new-h2">Register New Product</a> <h2> My Products </h2> 
  <form action="" method="get">
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
		<!--<th scope="col" id="cb" class="manage-column column-cb" style=""><label class="screen-reader-text" for="cb-select-all-1">Select All</label>
            <input id="cb-select-all-1" type="checkbox"></th>-->
          <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Vendor</span></th>
          <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Product Name</span></th>
		  <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Serial Code</span></th>
		  <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Link</span></th>
		  <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Register Date</span></th>
      </thead>
	  <?php foreach ($results as $data) { 
	  global $current_user;
      get_currentuserinfo();
	  
	      $prquery          =	"select * from wp_products where id = ".$data->product_id."";   
		  $resultpro 		= 	$wpdb->get_row($prquery);
		  $prodcutname		=   $resultpro->name;
		  $vendor           =   $resultpro->vendor;
		  $link             =   $resultpro->downloadlink;
	  ?>
	  <tr id="user-4" class="alternate">
      <!--<th scope="row" class=""><label class="screen-reader-text" for="cb-select-4">Select abbr1</label>
        <input type="checkbox" name="users[]" id="user_<?php echo $data->id; ?>" class="group_leader" value="<?php echo $data->id; ?>">
	  </th>-->
      <td class="username column-username">
	   <strong><?php echo $vendor ?></strong><br>
        </td>
      <td class="name column-name"><?php echo $prodcutname; ?></td>
	  <td class="name column-name"><?php echo $data->serial_code; ?></td>
	  <td class="name column-name"><?php echo $link; ?></td>
	  <td class="name column-name"><?php echo date('Y-m-d', strtotime($data->register_date)); ?></td>
    </tr>
	<?php } if(empty($results)){ echo "<center><strong>No Product Registered</strong></center>";} ?>
    </table>
  </form>
  <br class="clear">
</div>
<?php } ?>
		</div>
	</div>
</div>
<?php
//get_sidebar();
?>
<div id="secondary">
	<?php
		$description = get_bloginfo( 'description', 'display' );
		if ( ! empty ( $description ) ) :
	?>
	<h2 class="site-description"><?php echo esc_html( $description ); ?></h2>
	<?php endif; ?>

	<?php if ( has_nav_menu( 'secondary' ) ) : ?>
	<nav role="navigation" class="navigation site-navigation secondary-navigation">
		<?php wp_nav_menu( array( 'theme_location' => 'secondary' ) ); ?>
	</nav>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">
		<?php //dynamic_sidebar( 'sidebar-1' ); ?>
		<aside id="recent-posts-2" class="widget widget_recent_entries">
		<h1 class="widget-title"><a href="http://58.65.172.229:808/lovelysounds/my-account/">My Products</a></h1>
		<h1 class="widget-title"><a href="<?php echo home_url() ?>/wp-login.php?loggedout=true">Logout</a></h1>
	
		</aside>
	</div><!-- #primary-sidebar -->
	<?php endif; ?>
</div><!-- #secondary -->
<?php
get_footer();
