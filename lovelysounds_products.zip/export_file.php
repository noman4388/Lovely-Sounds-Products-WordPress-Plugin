<?php

global $wpdb;

if($_GET['action'] == 'export-register')
	{
		$export	=	array();
	$querydata = "select * from wp_serials where created_by = ".$_GET['proid']." AND registered_to_user != 0 order by `register_date` desc";
	$results   = $wpdb->get_results($querydata);
	  
	$querycreator   = 	"select * from wp_serialskeycreator where id = ".$_GET['proid']."";
	$queryreslt   	= 	$wpdb->get_row($querycreator);
	$creatorname  	= 	$queryreslt->name;
	$creatornotes  	= 	$queryreslt->notes;	
	$product_id		=   $queryreslt->product_id;
	$reseler_id		=   $queryreslt->group_id;
	
			$prquery          	=	"select * from wp_products where id = ".$product_id	."";   
		    $resultpro 			= 	$wpdb->get_row($prquery);
			$productname		=   $resultpro->name; 
			$vendor				=   $resultpro->vendor;
		  
			$grquery          	=	"select * from wp_productgroup where id = ".$reseler_id	."";   
			$resultgro 			= 	$wpdb->get_row($grquery);
			$resellername			=   $resultgro->name;
		$export[]['proname'] = $productname;
		$export[]['presellername'] = $resellername;
		$export[]['vendor'] = $vendor;
		$export[]['cretrname'] = $creatorname;
		$export[]['cretrnotes'] = $creatornotes;
$textdata = '{"proname":"Culture",
"name":"'.$creatorname.'",
"notes":"'.$creatornotes.'",
"product":"'.$productname.'",
"vendor":"'.$vendor.'",
"reseller":"'.$resellername.'",
"serials":
[';		
			foreach($results as $datarelt){
		$user_info = get_userdata($datarelt->registered_to_user);
        $userlogin	=	$user_info->user_login;
		$export['serials'][]['serailcode']		   = $datarelt->serial_code;
		$export['serials'][]['username']  		   = $userlogin;
		$export['serials'][]['numberactivation']   = $datarelt->num_activations;
	$textdata .= '{
"serailcode":"'.$datarelt->serial_code.'",
"username":"'.$userlogin.'",
"numberactivation":"'.$datarelt->num_activations.'",
},';	
	}
$textdata .=	']
}';	
		  $encodedtext	= json_encode($export);
		  $file = fopen(dirname(__FILE__)."/register_serial.json","w");
		  fwrite($file,$textdata);
		  fclose($file);
		  $siteurl = site_url()."/wp-content/plugins/lovelysounds/register_serial.json";
		  wp_redirect($siteurl);
		  exit;
	} 
	else if($_GET['action'] == 'export-unregister')
	{
		$export	=	array();
	$querydata = "select * from wp_serials where created_by = ".$_GET['proid']." AND registered_to_user = 0";
	$results   = $wpdb->get_results($querydata);
	  
	$querycreator   = 	"select * from wp_serialskeycreator where id = ".$_GET['proid']."";
	$queryreslt   	= 	$wpdb->get_row($querycreator);
	$creatorname  	= 	$queryreslt->name;
	$creatornotes  	= 	$queryreslt->notes;	
	$product_id		=   $queryreslt->product_id;
	$reseler_id		=   $queryreslt->group_id;
	
			$prquery          	=	"select * from wp_products where id = ".$product_id	."";   
		    $resultpro 			= 	$wpdb->get_row($prquery);
			$productname		=   $resultpro->name; 
			$vendor				=   $resultpro->vendor;
		  
			$grquery          	=	"select * from wp_productgroup where id = ".$reseler_id	."";   
			$resultgro 			= 	$wpdb->get_row($grquery);
			$resellername			=   $resultgro->name;
		$export[]['proname'] = $productname;
		$export[]['presellername'] = $resellername;
		$export[]['vendor'] = $vendor;
		$export[]['cretrname'] = $creatorname;
		$export[]['cretrnotes'] = $creatornotes;
		$textdata = '{"proname":"Culture",
"name":"'.$creatorname.'",
"notes":"'.$creatornotes.'",
"product":"'.$productname.'",
"vendor":"'.$vendor.'",
"reseller":"'.$resellername.'",
"serials":
[';	
			foreach($results as $datarelt){
				$export['serials'][]['serailcode']		   = $datarelt->serial_code;
	$textdata .= '
"'.$datarelt->serial_code.'",
';			
	}
	$textdata .=	']
}';	
          $encodedtext	= json_encode($export);
		  $file = fopen(dirname(__FILE__)."/unregister_serial.json","w");
		  fwrite($file,$textdata);
		  fclose($file);
		  $siteurl = site_url()."/wp-content/plugins/lovelysounds/unregister_serial.json";
		  wp_redirect($siteurl);
		  exit;
		  //exit;
	} 
 ?>