<style>
.error {color: #FF0000;}
</style>
<?php

global $wpdb;

if(isset($_POST['updatepro']))
{
$err = '';
$now = current_time('mysql', false);

if($_POST['pro_id'] == 0){
$err = '* Product id is not zero';
}

if(empty($err))
{
$query =  "UPDATE wp_products SET product_id = '".$_POST['pro_id']."', time = '".$now."', name = '".$_POST['pro_name']."', serial_prefix = '".$_POST['serail_prefix']."', downloadlink = '".$_POST['link']."', vendor = '".$_POST['vendorname']."', product_guid = '".$_POST['pro_guid']."'  WHERE id = ".$_GET['product_id']."";

$qry = $wpdb->query($query);

if($qry){
   echo "Product Updated successfully";
   echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=products'</script>");
   exit();
}
}

 }

 ?>
 <?php
 $querydata = "select * from wp_products where id = ".$_GET['product_id']."";
 $results = $wpdb->get_row($querydata);
  ?>
 <form action="" method="post" name="createuser" id="createuser" class="validate">
<table class="form-table">
	<tbody>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Product Name <span class="description">(required)</span></label></th>
		<td><input name="pro_name" type="text" id="pro_name" value="<?php echo $results->name ?>" required></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Product id</label></th>
		<td><input name="pro_id" type="text" value="<?php echo $results->product_id ?>" id="pro_id" required><span class="error"> <?php echo $err; ?></span></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Product guid</label></th>
		<td><input name="pro_guid" type="text" value="<?php echo $results->product_guid ?>" id="pro_guid" required></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="email">Vendor</span></label></th>
		<td><input name="vendorname" type="text" value="<?php echo $results->vendor ?>" id="vendorname" value=""></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="first_name">Serial Prefix </label></th>
		<td><input name="serail_prefix" type="text" maxlength="5" value="<?php echo $results->serial_prefix; ?>" id="serail_prefix" value=""></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="last_name">Download Link</label></th>
		<td><input name="link" type="text" value="<?php echo $results->downloadlink ?>" id="link" value=""></td>
	</tr>
	</tbody></table>

<p class="submit"><input type="submit" name="updatepro" id="updatepro" class="button button-primary" value="Update Product "></p>
</form>