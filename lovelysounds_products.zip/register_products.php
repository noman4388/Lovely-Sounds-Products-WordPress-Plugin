<style>
.error {color: #FF0000;}
</style>
<script type="text/javascript">
function returnurl(){
	location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=my-products';
}
</script>
<?php
global $wpdb;  
$now = current_time('mysql', false);
$user_id = get_current_user_id();
 
if(isset($_POST['registerproduct'])){  
   	$serailnmber 	 =	 $_POST['serail_number'];
   	$querypro  		 = 	 "select * from wp_serials where serial_code = '".$serailnmber."' ";
   	$getresult 		 = 	 $wpdb->get_row($querypro); 

	$queryserial  	 = 	 "select * from wp_productactivations where serial_id = '".$serailnmber."' ";
   	$serailresult 	 = 	 $wpdb->get_row($queryserial); 
	
	echo "<pre>";
	print_r($getresult);
	
	echo "<br>";
	
	echo "<pre>";
	print_r($serailresult);
	
	
	exit;
	
	
	if(!empty($getresult) && empty($serailresult))
	{
	$wpdb->insert('wp_productactivations', array(
    'activation_date'          =>  $now,
    'user_id' 				   =>  $user_id,
    'serial_id' 			   =>  $getresult->serial_code,
    'product_id'  			   =>  $getresult->product_id,
));

if($wpdb->insert_id){
   $updatequery =  "UPDATE wp_serials SET  register_date = '".$now."', registered_to_user = '".$user_id."' WHERE serial_code = '".$_POST['serail_number']."'";
   $updateqry = $wpdb->query($updatequery);
  echo "<strong>Product Registered successfully</strong><br>"; 
  echo "<input type='button' name='data' value='Ok' onclick='returnurl();' >";
  /*echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=my-products</script>");*/
  exit();
}
	}

if(!empty($serailresult)){
        $error = 'Serial Key is Already Registered';
 }	
 else{
        $error = "Invalid Serial Key";
 }
}

?>
<h2>Please Enter your Serial Number</h2>
   <span class="error"><strong><?php echo $error; ?></strong></span>
<form action="" method="post" name="createuser" id="createuser" class="validate">
<table class="form-table">
	<tbody>
	<tr class="form-field">
		<th scope="row"><label for="first_name">Serial: </label></th>
		<td><input name="serail_number" type="text" id="serail_number" value="<?php echo $_POST['serail_number'] ?>" required></td>
	</tr>
	</tbody></table>

<p class="submit"><input type="submit" name="registerproduct" id="registerproduct" class="button button-primary" value="Send"></p>
</form>
