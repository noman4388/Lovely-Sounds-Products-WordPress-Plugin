<?php 
ob_start();
    /*
    Plugin Name: Products Details 
    Plugin URI: http://nomanakhtar.com/
    Description: Define Product Details
    Author: Noman Akhtar
    Version: 1.0
    Author URI: http://nomanakhtar.com/
    */
	
		require_once(ABSPATH .'/wp-admin/includes/plugin.php');
	    require_once(ABSPATH .'/wp-includes/pluggable.php');
		
		/// Create page and assing template to this page from plugin 
		
register_activation_hook( __FILE__, 'create_uploadr_page' );
    function create_uploadr_page() {

        $post_id = -1;

        // Setup custom vars
        $author_id = get_current_user_id();;
        $slug = 'my-account-testing';
        $title = 'my account testing';

        // Check if page exists, if not create it
        if ( null == get_page_by_title( $title )) {

            $uploader_page = array(
                    'comment_status'        => 'closed',
                    'ping_status'           => 'closed',
                    'post_author'           => $author_id,
                    'post_name'             => $slug,
                    'post_title'            => $title,
                    'post_status'           => 'publish',
                    'post_type'             => 'page'
            );

            $post_id = wp_insert_post( $uploader_page );


            if ( !$post_id ) {

                    wp_die( 'Error creating template page' );

            } else {

                    update_post_meta( $post_id, '_wp_page_template', 'my_account.php' );

            }
        } // end check if

    }

    add_action( 'template_include', 'uploadr_redirect' );
    function uploadr_redirect( $template ) {

        $plugindir = dirname( __FILE__ );

        if ( is_page_template( 'my_account.php' )) {

            $template = $plugindir . '/templates/my_account.php';
        }

        return $template;

    }
		
/* Function to restrict non admin user from accessing admin dashboard */		
	/* */
	function user_restrict_admin() { 
	if ( ! current_user_can( 'manage_options' )  && $_SERVER['PHP_SELF'] != '/wp-admin/admin-ajax.php' ) 
	{
			wp_redirect( home_url().'/my-account/' );
	}
	}
	add_action( 'admin_init', 'user_restrict_admin', 1 );
	
	global $jal_db_version;
	$jal_db_version = "1.0";
	
	function jal_install() {
	global $wpdb;
	global $jal_db_version;
	
	/*Product table*/
	$table_name = $wpdb->prefix . "products";
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
	  name tinytext NOT NULL,
	  serial_prefix VARCHAR(100) DEFAULT '' NOT NULL,
	  downloadlink VARCHAR(100) DEFAULT '' NOT NULL,
	  vendor VARCHAR(100) DEFAULT '' NOT NULL,
	  product_id VARCHAR(55) DEFAULT '' NOT NULL,
	  product_guid VARCHAR(100) DEFAULT '' NOT NULL,
	  UNIQUE KEY id (id)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
	
	
	$wpdb->query($sql);
	
	/* Group table */
	$table_name1 = $wpdb->prefix . "productgroup";
	$sql1 = "CREATE TABLE IF NOT EXISTS $table_name1 (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
	  name VARCHAR(55) DEFAULT '' NOT NULL,
	  notes VARCHAR(55) DEFAULT '' NOT NULL,
	  UNIQUE KEY id (id)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
	
	
	$wpdb->query($sql1);
	
	
	/* Serials key table */
	$table_name2 = $wpdb->prefix . "serials";
	$sql2 = "CREATE TABLE IF NOT EXISTS $table_name2 (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  serial_code VARCHAR(55) DEFAULT '' NOT NULL,
	  product_id VARCHAR(55) DEFAULT '' NOT NULL,
	  registered_to_user VARCHAR(55) DEFAULT '' NOT NULL,
	  created_by VARCHAR(55) DEFAULT '' NOT NULL,
	  num_activations VARCHAR(55) DEFAULT '' NOT NULL,
	  register_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
	  UNIQUE KEY id (id)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
	
	
	$wpdb->query($sql2);
	
	/* Serials key creator table */
	$table_name3 = $wpdb->prefix . "serialskeycreator";
	$sql3 = "CREATE TABLE IF NOT EXISTS $table_name3 (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  create_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
	  name tinytext NOT NULL,
	  notes VARCHAR(55) DEFAULT '' NOT NULL,
	  number_of_serials VARCHAR(55) DEFAULT '' NOT NULL,
	  product_id VARCHAR(55) DEFAULT '' NOT NULL,
	  group_id VARCHAR(55) DEFAULT '' NOT NULL,
	  UNIQUE KEY id (id)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
	
	
	$wpdb->query($sql3);
	
	/* registered product table */
	$table_name4 = $wpdb->prefix . "registeredproduct";
	$sql4 = "CREATE TABLE IF NOT EXISTS $table_name4 (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  register_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
	  user_id VARCHAR(55) DEFAULT '' NOT NULL,
	  serial_code VARCHAR(55) DEFAULT '' NOT NULL,
	  product_id VARCHAR(55) DEFAULT '' NOT NULL,
	  UNIQUE KEY id (id)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
	
	
	$wpdb->query($sql4);
	
	/* productactivations table */
	$table_name5 = $wpdb->prefix . "productactivations";
	$sql5 = "CREATE TABLE IF NOT EXISTS $table_name5 (
	  id mediumint(9) NOT NULL AUTO_INCREMENT,
	  activation_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
	  user_id VARCHAR(55) DEFAULT '' NOT NULL,
	  serial_id VARCHAR(55) DEFAULT '' NOT NULL,
	  product_id VARCHAR(55) DEFAULT '' NOT NULL,
	  UNIQUE KEY id (id)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;";
	
	
	$wpdb->query($sql5);
	
	}

function jal_install_data() {
   global $wpdb;
   $table_name = $wpdb->prefix . "classes";
   $welcome_name = "Mr. Wordpress";
   $welcome_text = "Congratulations, you just completed the installation!";

   $rows_affected = $wpdb->insert( $table_name, array( 'time' => current_time('mysql'), 'name' => $welcome_name, 'text' => $welcome_text ) );
}
register_activation_hook(__FILE__,'jal_install');
//register_activation_hook(__FILE__,'jal_install_data');
	
add_action( 'admin_menu', 'register_my_custom_menu_page' );
function register_my_custom_menu_page(){
    add_menu_page("Products", "Products", 0, "products","myMenuPageFunction" ); 
	add_submenu_page("products", "Resellers", "Resellers", 0, "groups", "mySubmenuPageFunction1");	
	add_submenu_page("products", "Serials Management", "Serials Management", 0, "serials-management", "mySubmenuPageFunction2");
	add_submenu_page("products", "Activation Management", "Activation Management", 0, "activation-management", "mySubmenuPageFunction3");
	//add_submenu_page("products", "My Products", "My Products", 0, "my-products", "mySubmenuPageFunction4");	
	add_submenu_page("products", "", "", 0, "add-newproduct", "mySubmenuPageFunction5");
	add_submenu_page("products", "", "", 0, "edit-product", "mySubmenuPageFunction6");
	add_submenu_page("products", "", "", 0, "delete-product", "mySubmenuPageFunction7");
	add_submenu_page("products", "", "", 0, "add-newgroup", "mySubmenuPageFunction8");
	add_submenu_page("products", "", "", 0, "edit-newgroup", "mySubmenuPageFunction9");
	add_submenu_page("products", "", "", 0, "delete-newgroup", "mySubmenuPageFunction10");
	add_submenu_page("products", "", "", 0, "add-newserials", "mySubmenuPageFunction11");
	add_submenu_page("products", "", "", 0, "register-newproduct", "mySubmenuPageFunction12");
}

function myMenuPageFunction(){
	include('products.php');
}

function mySubmenuPageFunction1(){
	include('groups.php');
}

function mySubmenuPageFunction2(){
    
	if($_GET['action']== 'details'){
	  include('serial_detail.php');	
	}
	else if($_GET['action'] == 'export-register' || $_GET['action'] == 'export-unregister')
	{
		include('export_file.php');
	}
	else
	{
	include('serials.php');
	}
}

function mySubmenuPageFunction3(){
    include('activaton.php'); 
}

function mySubmenuPageFunction4(){
    include('myproducts.php');
}

function mySubmenuPageFunction5(){
	include('add_products.php');
}

function mySubmenuPageFunction6(){
    include('edit_products.php');
}

function mySubmenuPageFunction7() {
   include('delete_products.php');
}

function mySubmenuPageFunction8(){
    include('add_groups.php');
}

function mySubmenuPageFunction9(){
    include('edit_newgroup.php');
}

function mySubmenuPageFunction10(){
   include('delete_group.php');
}

function mySubmenuPageFunction11(){
   include('add_serials.php'); 
}

function mySubmenuPageFunction12(){
   include('register_products.php'); 
}

?>