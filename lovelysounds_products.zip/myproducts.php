<?php
global $wpdb;
$user_id = get_current_user_id();
$querydata = "select * from wp_serials where registered_to_user = '".$user_id ."'";
$results = $wpdb->get_results($querydata);
 ?>
<div class="wrap">
 <h2> My Products <a href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=register-newproduct" class="add-new-h2">Register New Product</a> </h2>
  <form action="" method="get">
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
		<th scope="col" id="cb" class="manage-column column-cb" style=""><label class="screen-reader-text" for="cb-select-all-1">Select All</label>
            <input id="cb-select-all-1" type="checkbox"></th>
          <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Vendor</span></th>
          <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Product Name</span></th>
		  <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Serial Code</span></th>
		  <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Link</span></th>
		  <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><span>Register Date</span></th>
      </thead>
	  <?php foreach ($results as $data) { 
	  global $current_user;
      get_currentuserinfo();
	  
	      $prquery          =	"select * from wp_products where id = ".$data->product_id."";   
		  $resultpro 		= 	$wpdb->get_row($prquery);
		  $prodcutname		=   $resultpro->name;
		  $vendor           =   $resultpro->vendor;
		  $link             =   $resultpro->downloadlink;
	  ?>
	  <tr id="user-4" class="alternate">
      <th scope="row" class=""><label class="screen-reader-text" for="cb-select-4">Select abbr1</label>
        <input type="checkbox" name="users[]" id="user_<?php echo $data->id; ?>" class="group_leader" value="<?php echo $data->id; ?>"></th>
      <td class="username column-username">
	   <strong><?php echo $vendor ?></strong><br>
        </td>
      <td class="name column-name"><?php echo $prodcutname; ?></td>
	  <td class="name column-name"><?php echo $data->serial_code; ?></td>
	  <td class="name column-name"><?php echo $link; ?></td>
	  <td class="name column-name"><?php echo $data->register_date; ?></td>
    </tr>
	<?php } ?>
    </table>
  </form>
  <br class="clear">
</div>
