<?php

global $wpdb;

$querydelete = "DELETE FROM `wp_productgroup` WHERE `id` = ".$_GET['group_id']."";

$query       = $wpdb->query($querydelete);

if($query){
   echo "Group Deleted successfully";
   echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=groups'</script>");
   exit();
}


 ?>