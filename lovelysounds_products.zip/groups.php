<?php
global $wpdb;

$querydata = "select * from wp_productgroup";

$results = $wpdb->get_results($querydata);
 ?>
<div class="wrap">
  <h2> Resellers <a href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=add-newgroup" class="add-new-h2">Add New Reseller</a> </h2>
  <form action="" method="get">
    <table class="wp-list-table widefat fixed users">
      <thead>
        <tr>
		<th scope="col" id="cb" class="manage-column column-cb" style=""><label class="screen-reader-text" for="cb-select-all-1">Select All</label>
            <input id="cb-select-all-1" type="checkbox"></th>
          <th scope="col" id="username" class="manage-column column-username sortable desc" style=""><a href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?orderby=login&amp;order=asc"><span>Reseller Name</span><span class="sorting-indicator"></span></a></th>
          <th scope="col" id="email" class="manage-column column-email sortable desc" style=""><a href="http://58.65.172.229:808/evs/noman/wordpressnewsite/wp-admin/users.php?orderby=email&amp;order=asc"><span>Notes</span><span class="sorting-indicator"></span></a></th>
      </thead>
	  <?php foreach ($results as $data) { ?>
	  <tr id="user-4" class="alternate">
      <th scope="row" class=""><label class="screen-reader-text" for="cb-select-4">Select abbr1</label>
        <input type="checkbox" name="users[]" id="user_<?php echo $data->id; ?>" class="group_leader" value="<?php echo $data->id; ?>"></th>
      <td class="username column-username">
	   <strong>
	   <a href="http://58.65.172.229:808/lovelysounds/wp-admin/user-edit.php?user_id=4&amp;wp_http_referer=%2Fevs%2Fnoman%2Fwordpressnewsite%2Fwp-admin%2Fusers.php"><?php echo $data->name ?></a></strong><br>
        <div class="row-actions">
		<span class="edit"><a href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=edit-newgroup&group_id=<?php echo $data->id; ?>">Edit</a> | </span>
		<?php
		$queryprocheck = "select * from wp_serialskeycreator where group_id = '".$data->id."'";
		$resultcheck = count($wpdb->get_results($queryprocheck));
		if($resultcheck == 0)
		{
		 ?>
		<span class="delete">
		<a onclick="return confirm('Are you sure you want to delete this product?');" class="submitdelete" href="http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=delete-newgroup&group_id=<?php echo $data->id; ?>">Delete</a>
		</span>
		<?php } ?>
		</div></td>
      <td class="name column-name"><?php echo $data->notes ?></td>
    </tr>
	<?php } ?>
    </table>
  </form>
  <br class="clear">
</div>
