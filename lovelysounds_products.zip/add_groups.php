<style type="text/css">
.wp-admin select{ width:25em;}
.error {color: #FF0000;}
</style>
<?php
global $wpdb;
if(isset($_POST['addgroup']))
{

$now1 = current_time('mysql', false);
$error = '';

if(empty($_POST['grop_name'])){
  $error = 'Please Enter Resller Name';
}
if(empty($error))
{
$wpdb->insert('wp_productgroup', array(
    'time'          => $now1,
    'name' 			=> $_POST['grop_name'],
    'notes' 	    => $_POST['grop_note'],
));
$wpdb->last_error; 
if($wpdb->insert_id){
  echo "<strong>Group added successfully</strong>"; 
  echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=groups'</script>");
  exit();
}
}
}
?>
<script src="//code.jquery.com/jquery-1.9.1.js"></script>
  <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
  
  <!-- jQuery Form Validation code -->
  <script>
  // When the browser is ready...
  $(function() {
  
    // Setup form validation on the #register-form element
    $("#createuser").validate({
    
        // Specify the validation rules
        rules: {
            grop_name: "required",
            pro_id: "required",
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 5
            },
            testfield: "required"
        },
        
        // Specify the validation error messages
        messages: {
            grop_name: "Please Enter Reseller Name",
            pro_id: "Please enter your Product id"
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

  });
  </script>

<h2>Enter Reseller Details</h2>
<form action="" method="post" name="createuser" id="createuser" class="validate">
<table class="form-table">
	<tbody>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Reseller Name <span class="description">(required)</span></label></th>
		<td><input name="grop_name" type="text" id="grop_name"><span class="error"><?php echo $error; ?></span></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Notes</label></th>
		<td><input name="grop_note" type="text" id="grop_note"></td>
	</tr>
	</tbody></table>
<p class="submit"><input type="submit" name="addgroup" id="addgroup" class="button button-primary" value="Add New Group"></p>
</form>

