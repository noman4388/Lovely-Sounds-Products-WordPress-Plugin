<style>
.error {color: #FF0000;}
</style>
<?php
global $wpdb;
if(isset($_POST['createpro']))
{
$err = '';
$now = current_time('mysql', false);

if($_POST['pro_id'] == 0){
$err = '* Product id is not zero';
}

if(empty($_POST['pro_name'])){
$errproname = '* Please Enter Product Name';
}
if(empty($_POST['pro_guid'])){
$errgro = '* Please Enter Group ID ';
}

if(empty($err) && empty($errgro) &&empty($errproname))
{
$wpdb->insert('wp_products', array(
    'time'          => $now,
    'name' 			=> $_POST['pro_name'],
    'product_id' 	=> $_POST['pro_id'],
    'product_guid'  => $_POST['pro_guid'],
	'vendor' 		=> $_POST['vendorname'],
	'serial_prefix' => $_POST['serail_prefix'],
	'downloadlink'  => $_POST['link'],
));
if($wpdb->insert_id){
  echo "<strong>Product added successfully</strong>"; 
  echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=products'</script>");
  exit();
}
}
}
?>
<script src="//code.jquery.com/jquery-1.9.1.js"></script>
  <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
  
  <!-- jQuery Form Validation code -->
  <script>
  // When the browser is ready...
  $(function() {
  
    // Setup form validation on the #register-form element
    $("#createuser").validate({
    
        // Specify the validation rules
        rules: {
            pro_name: "required",
			pro_guid: "required",
            pro_id: "required",
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 5
            },
            testfield: "required"
        },
        
        // Specify the validation error messages
        messages: {
            pro_name: "Please enter your Product name",
            pro_guid: "Please enter your Product Guid",
            pro_id: "Please enter your Product id"
        },
        
        submitHandler: function(form) {
            form.submit();
        }
    });

  });
  </script>
<h2>Enter Product Details</h2>
<form action="" method="post" name="createuser" id="createuser" novalidate="novalidate">
<table class="form-table">
	<tbody>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Product Name <span class="description">(required)</span></label></th>
		<td><input name="pro_name" type="text" id="pro_name" value="<?php echo $_POST['pro_name'] ?>" ><span class="error"><?php echo $errproname;?></span></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Product id</label></th>
		<td><input name="pro_id" type="text" id="pro_id" value="<?php echo $_POST['pro_id'] ?>"><span class="error"> <?php echo $err;?></span></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Product guid</label></th>
		<td><input name="pro_guid" type="text" value="<?php echo $_POST['pro_guid'] ?>" id="pro_guid"><span class="error"><?php echo $errgro;?></span>	
		 </td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="email">Vendor</span></label></th>
		<td><input name="vendorname" type="text"  id="vendorname" value="<?php echo $_POST['vendorname'] ?>"></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="first_name">Serial Prefix </label></th>
		<td><input name="serail_prefix" type="text" maxlength="5" id="serail_prefix" value="<?php echo $_POST['serail_prefix'] ?>"></td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="last_name">Download Link</label></th>
		<td><input name="link" type="text" id="link" value="<?php echo $_POST['link'] ?>"></td>
	</tr>
	</tbody></table>

<p class="submit"><input type="submit" name="createpro" id="createusersub" class="button button-primary" value="Add New Product "></p>
</form>
