<?php 
global $wpdb;

if(isset($_POST['updategroup'])){

$now = current_time('mysql', false);
      
	 $query =  "UPDATE wp_productgroup SET  time = '".$now."', name = '".$_POST['grop_name']."', notes = '".$_POST['grop_notes']."' WHERE id = ".$_GET['group_id']."";
	  $qry = $wpdb->query($query);

if($qry){
   echo "Group Updated successfully";
   echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=groups'</script>");
   exit();
}
}

?>




<?php
 $querydata = "select * from wp_productgroup where id = ".$_GET['group_id']."";
 $results = $wpdb->get_row($querydata);
  ?>
<h2>Update Reseller Details</h2>
 <form action="" method="post" name="createuser" id="createuser" class="validate">
<table class="form-table">
	<tbody>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Reseller Name <span class="description">(required)</span></label></th>
		<td><input name="grop_name" type="text" id="grop_name" value="<?php echo $results->name ?>" required></td>
	</tr>
	<tr class="form-field form-required">
		<th scope="row"><label for="user_login">Notes</label></th>
		<td><input name="grop_notes" type="text" value="<?php echo $results->notes ?>" id="grop_notes" required></td>
	</tr>
	</tbody></table>

<p class="submit"><input type="submit" name="updategroup" id="updategroup" class="button button-primary" value="Update Group "></p>
</form>