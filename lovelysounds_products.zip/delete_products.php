<?php

global $wpdb;

$querydelete = "DELETE FROM `wp_products` WHERE `id` = ".$_GET['product_id']."";

$query       = $wpdb->query($querydelete);

if($query){
   echo "Product Deleted successfully";
   echo ("<script>location.href='http://58.65.172.229:808/lovelysounds/wp-admin/admin.php?page=products'</script>");
   exit();
}


 ?>